/* Octave ships its own config.h and these macros conflict with us*/
#undef HAVE_TR1_UNORDERED_MAP
#undef HAVE_UNORDERED_MAP
#undef USE_UNORDERED_MAP_WITH_TR1
