% w = hann(n)
%   see hanning
function w = hann(n), w=hanning(n);
